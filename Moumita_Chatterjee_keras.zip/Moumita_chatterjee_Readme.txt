Open a ner pyhton 3 file
Load the necessary packages (specially keras)
load the dataset and convert in dataframe
Run the codes